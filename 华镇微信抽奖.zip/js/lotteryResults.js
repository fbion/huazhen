$(function(){
	ManagePageResults.GetEndDrawSeting();
});
var ManagePageResults = {
	GetEndDrawSeting : function(){
        $.getJSON(PATH_ACTIVITY+ "/lottery/endDrawSeting?jsoncallback=?",
        function(data) {
            //alert("123124");
            for (var i = 0; i <= data.awards.length - 1; i++) {
            	var award = data.awards[i];
            	var a = null;
            	//alert($('.clearfix').length);
        		a = $($('.clearfix').get(0)).clone();
       			a.css({"display":"block"});
       			a.find(".results-num").html(award.round);
       			a.find(".result-pride").html(award.drawAwards);
       			a.prependTo(".rhLottery");
            ManagePageResults.GetWinnersByDraw(award.id,a);
            	//alert(award.drawAwards);
            };
            //$(".usercount-label").html(data.count+"人");
        });
    },
    GetWinnersByDraw : function(drawNo,obj){
      $.getJSON(PATH_ACTIVITY+"/lottery/winnersByDraw?jsoncallback=?",
        {id:drawNo},
        function(data){
          for (var i = data.winners.length - 1; i >= 0; i--) {
            var winner = data.winners[i];
            var b=$($('.result-line.result-user').get(0)).clone();
            b.css({"display":"block"});
            b.find(".result-num").html(i+1);
            b.find(".nick-name").html(winner.userName);
            b.find(".user").css({
                "background-image": "url(" + winner.imgPath + ")"
            });
            b.appendTo(obj);
          };
        });
    }
};