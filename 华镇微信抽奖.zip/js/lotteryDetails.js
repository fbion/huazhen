var Winers;
var curr_index = 0;
var flgPlaying = false;
var tmr_playanimate;
var stop_playanimate;
var Players;
var winer_count = 0;
//var $ResultSeed = $(".lottery-right .result-line");

$(function(){

   // alert($ResultSeed);
    $(".control.button-run").on("click",function() {
            ManagePage.Start_game();
        });
    $(".control.button-stop").on("click",
        function() {
            ManagePage.Stop_game();
            window.clearTimeout(stop_playanimate)
        });
    /*$(".button-reset").on("click",
        function() {
            ManagePage.GetLatelyDraw();
            $(".lottery-right").html('<div class="result-line" style="display: none;"></div>');
        });*/
    //ManagePage.NextBandClick();
    $(".button-reset").removeClass("lottery-bottom").addClass("reset-button").unbind("click");
    ManagePage.GetAllplayer();
    ManagePage.GetLatelyDraw();//0初始化时
});
var ManagePage = {
    NextBandClick : function(){
        $(".button-reset").on("click",
        function() {
            $(".button-reset").removeClass("lottery-bottom").addClass("reset-button").unbind("click");
            ManagePage.GetLatelyDraw();//下一轮抽奖
            $(".lottery-right").html('<div class="result-line" style="display: none;"></div>');
        });
    },
    Start_game : function() {
        winer_count = $(".select-value").text() * 1;//选取的抽奖人数
        var a = parseInt($(".lottery-title .usercount-label").text());//抽奖总人数
        if (a>=0) {
            $(".control.button-run").hide();
            flgPlaying = true;
            curr_index = 0;

            $.getJSON(PATH_ACTIVITY + "/lottery/getCurrentDrawSetingStatus?jsoncallback=?", {//获奖人数
                currentNo: $("#round").val(),
                },
                function(data) {
                    if (data.res==0) {
                        $(".control.button-run").show();
                        sAlert("本轮抽奖已经结束，请开始下轮抽奖！");
                    }else{
                        //Winers = data.winers;
                        ManagePage.Playanimate();
                        window.setTimeout(function() {
                            $(".control.button-stop").fadeIn()
                        },500);
                        /*if (audio_Running) {
                            audio_Running.play()
                        }*/
                    };
                })
        }else {
            sAlert("参与人数为0！");
        }
    }, 
    Stop_game : function() {
        $(".control.button-stop").hide();
        $(".control.button-run").show();
        $.getJSON(PATH_ACTIVITY + "/lottery/getLotteryWinners?jsoncallback=?", {//获奖人数
                id: $("#round").val(),
                num: winer_count
                },
                function(data) {
                    Winers = data.winers;
                     ManagePage.GetWiner();
                })
       
        $(".button-reset").removeClass("reset-button").addClass("lottery-bottom");
        ManagePage.NextBandClick();
        ManagePage.UpdateDrawSetingStatus()

        
        /*if ($.isArray(Players)) {
            winer_count = $(".select-value").text() * 1;
            var a = parseInt($(".lottery-title .usercount-label").text());
            if (winer_count <= a) {
                $(".lottery-title .usercount-label").html(a - winer_count);
                getWiner()
            }
        }*/
    },
    Playanimate : function() {//微信头像动态展示
        if (Players[curr_index]) {
            var a = Players[curr_index];
            $(".lottery-run .user").css({
                "background-image": "url(" + a.imgPath + ")"
            });
            $(".lottery-run .user .nick-name").html(a.userName);
            curr_index++;
            if (curr_index >= Players.length) {
                curr_index = 0
            }
            if (flgPlaying) {
                tmr_playanimate = window.setTimeout(ManagePage.Playanimate, 100)
            }
        }
    },
    GetAllplayer : function() {//获取所有参与者
        $.getJSON(PATH_ACTIVITY+ "/lottery/allLotteryMember?jsoncallback=?",
        function(data) {
            //alert("123124");
            Players = data.activityUser;
            $(".usercount-label").html(data.count+"人");
        });
    },
    GetLatelyDraw : function(){//获取最近抽奖轮次
        $.getJSON(PATH_ACTIVITY+"/lottery/minDrawSeting?jsoncallback=?",function(data){
            if (data.res==1) {
                $(".title-label").html(data.draw.drawAwards);
                $(".select-value").html(data.draw.drawNumber);
                $("#round").val(data.draw.id);
            }else{
                //alert(data.res);
                $(".button-run").unbind("click");
                $(".button-run").removeClass().addClass("run-button");
                $(".title-label").html("抽奖结束");
                $(".select-value").html("0");
            };
            //alert($("#round").val());
        });
    },
    UpdateDrawSetingStatus : function(){
        $.getJSON(PATH_ACTIVITY+"/lottery/updateDrawSeting?jsoncallback=?",{
            currentNo : $("#round").val()
        },
        function(data){ 
        });
    },
    /*GetNextDraw : function(){//获取下一次抽奖
        $.getJSON(PATH_ACTIVITY+"/lottery/nextDrawSeting?jsoncallback=?",{
            currentNo : $("#round").val()//当前的抽奖轮次
        },function(data){
            $(".title-label").html(data.drawAwards);
            $(".select-value").html(data.drawNumber);
            $("#round").val(data.id);
        });

    },*/
    GetWiner : function() {
        flgPlaying = false;
        window.clearTimeout(tmr_playanimate);
        var a = Winers;
        for (var b = a.length - 1; b >= 0; b--) {
            $(".lottery-run .user").css({
                "background-image": "url(" + a[b].userImgPath + ")"
            }).attr({
                //lid: a[b].id,
                imgPath: a[b].userImgPath,
                //mid: a[b].mid,
                //sex: a[b].sex,
                userName: a[b].userName
            });
            $(".lottery-run .user .nick-name").html(a[b].userName);
            //$(".result-line")
            ManagePage.GetUser();
        }
        window.setTimeout(function() {
            $(".lottery-run .user").attr("style", "");
            $(".lottery-run .user .nick-name").html("")
        },
        300);
        ManagePage.GetAllplayer();
    },
    GetUser : function() {
        /*if (audio_GetOne) {
            audio_GetOne.play()
        }*/
       // alert($ResultSeed);
        $(".lottery-right").scrollTop(0);
        var b = $(".lottery-right").scroll(0).children(".result-line").length - 1;
        var a = null;
        a = $($('.lottery-right .result-line').get(0)).clone();
        a.css({"display":"block"})
        a.find(".result-num").html((b + 1));
        a.prependTo(".lottery-right").slideDown();
        var e = a.offset();
        var c = $(".lottery-run .user");
        var d = c.clone().appendTo("body").css({
            position: "absolute",
            top: c.offset().top,
            left: c.offset().left,
            width: c.width(),
            height: c.height()
        }).animate({
            width: 60,
            height: 60,
            top: e.top + 5,
            left: e.left + 50
        },
        500,
        function() {
            var g = d.css("background-image");
            d.appendTo(a).removeAttr("style").css({
                "background-image": g
            })
        })
    }
}
